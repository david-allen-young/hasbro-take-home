#include "LayeredAttributesUnitTests.hpp"

int main()
{
	LayeredAttributesUnitTests tests;
	tests.runSafeTests();
	// Warning: These tests are expected to throw an error
	//tests.runCrashTests();
    return 0;
}


