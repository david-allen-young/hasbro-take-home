#include "LayeredAttributesUnitTests.hpp"

int main()
{
	LayeredAttributesUnitTests tests;
	tests.runTests();
    return 0;
}


